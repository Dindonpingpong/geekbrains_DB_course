CREATE TABLE media (id serial primary key, 
path varchar(255), 
name varchar(255), 
description varchar(255)
);